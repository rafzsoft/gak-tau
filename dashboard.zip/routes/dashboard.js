import express from "express";
import moment from "moment";

const router = express.Router();

router.get("/", (req, res) => {
  res.render("index", { title: "Pairing | WhatsApp Dashboard" });
});

router.get("/dashboard", (req, res) => {
  res.render("dashboard", {
    title: "Dashboard Bot",
    uptime: moment().format("HH:mm:ss"),
  });
});

export default router;
