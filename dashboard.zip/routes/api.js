import express from "express";
const router = express.Router();

router.get("/status", (req, res) => {
  res.json({
    status: "connected",
    uptime: process.uptime().toFixed(0) + "s",
    botName: "AshiroMina᭄",
  });
});

router.post("/pair", (req, res) => {
  res.json({ success: true, message: "Pairing berhasil (simulasi)" });
});

export default router;
