const pairBtn = document.getElementById("pairBtn");
const refreshBtn = document.getElementById("refreshBtn");
const statusDiv = document.getElementById("status");

if (pairBtn) {
  pairBtn.addEventListener("click", async () => {
    const res = await fetch("/api/pair", { method: "POST" });
    const data = await res.json();
    alert(data.message);
    window.location.href = "/dashboard";
  });
}

if (refreshBtn) {
  refreshBtn.addEventListener("click", async () => {
    const res = await fetch("/api/status");
    const data = await res.json();
    statusDiv.innerHTML = `
      <p>Status: <b>${data.status}</b></p>
      <p>Uptime: ${data.uptime}</p>
      <p>Bot Name: ${data.botName}</p>
    `;
  });
}
